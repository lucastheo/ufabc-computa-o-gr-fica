#ifndef IO_H
#define IO_H


class io
{
public:
    io();
};

#endif // IO_H
